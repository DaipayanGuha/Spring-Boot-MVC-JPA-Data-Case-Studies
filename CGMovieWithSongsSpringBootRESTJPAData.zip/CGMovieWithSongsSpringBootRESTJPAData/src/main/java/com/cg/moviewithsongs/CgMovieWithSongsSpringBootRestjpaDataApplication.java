package com.cg.moviewithsongs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgMovieWithSongsSpringBootRestjpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgMovieWithSongsSpringBootRestjpaDataApplication.class, args);
	}

}
